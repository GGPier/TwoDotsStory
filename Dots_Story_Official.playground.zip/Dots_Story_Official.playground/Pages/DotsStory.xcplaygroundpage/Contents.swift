import UIKit
import SwiftUI
import PlaygroundSupport
import AVKit


class SoundManager {
    
    static let instance = SoundManager() //Singleton
    
    var player: AVAudioPlayer?
    
    enum SoundOption: String{
        case sound1
        case sound2
    }
    
    func playSound(sound: SoundOption){
        
        guard let url = Bundle.main.url(forResource:"sound1", withExtension: ".mp3")
      
        else {return}
    
        do{
            
            player = try AVAudioPlayer(contentsOf: url)
            player?.play()
            player?.numberOfLoops = -1
            
        
        }catch let error{
            print("Error playing sound. \(error.localizedDescription)")
        }
    }
}


struct IntroView: View {
    
    @State var rotation = 0.0
    @State var scalaXY = 1.0
    @State var positionX = -150
    @State var opacity_text1 = 0
    @State var opacity_text2 = 0
    @State var opacity_text3 = 0
    @State var opacity_text4 = 0
    @State var opacity_circle1 = 0
    @State var scalaXYC = 1
    @State var showMe = true
    @State var opacityButton = 0
    @State var animationAmount: CGFloat = 0.0
    
    var body: some View {
        
            ZStack {
                
            Image(uiImage: UIImage(named:"sheet.jpeg")!)
            .resizable()
            .frame(width: 50, height: 30)
            .rotationEffect(.degrees(rotation))
            .scaleEffect(CGFloat(scalaXY))
            .animation(Animation.easeInOut(duration:3))
            .onAppear(){
                rotation += 90
                scalaXY += 13.0
            }
            
                Image(uiImage: UIImage(named:"greendot1.png")!)
                    .resizable()
                .frame(width: 5, height: 5)
                .offset(x: 0, y: 48)
                .opacity(Double(opacity_circle1))
                .scaleEffect(CGFloat(scalaXYC))
                .animation(Animation.easeInOut(duration:3).delay(4))
                .onAppear(){
                     opacity_circle1 += 1
                    scalaXYC += 2
                }
            
            
            //Primo Testo
            
                VStack {
                
            Text("Once upon a time")
            .font(.system(size: 17, weight: .light, design: .rounded))
            .foregroundColor(.black)
            .italic()
            .opacity(Double(opacity_text1))
            .animation(Animation.easeInOut(duration:4).delay(1))
            .onAppear() {
                opacity_text1 += 1
                            }
                        

         
            
            //Secondo Testo
            
            
            Text("there were two dots living on a white sheet.")
                .font(.system(size: 17, weight: .light, design: .rounded))
                    .foregroundColor(.black)
                    .italic()
                    .opacity(Double(opacity_text2))
                    .animation(Animation.easeInOut(duration:6).delay(2))
                    .onAppear() {
                        opacity_text2 += 1
                    }
            
            
            //Terzo Testo
            
            
            Text("\nNo one knew the existence of the other one.")
                .font(.system(size: 17, weight: .light, design: .rounded))
                    .foregroundColor(.black)
                    .italic()
                    .opacity(Double(opacity_text3))
                    .animation(Animation.easeInOut(duration:7).delay(4))
                    .onAppear() {
                        opacity_text3 += 1
                    }
                }
            
                
            
                Image(uiImage: UIImage(named:"yellowdot1.png")!)
                    .resizable()
                .frame(width: 5, height: 5)
                .offset(x: 0, y: -48)
                .opacity(Double(opacity_circle1))
                .scaleEffect(CGFloat(scalaXYC))
                .animation(Animation.easeInOut(duration:3).delay(4))
                .onAppear() {
                     opacity_circle1 += 1
                    scalaXYC += 2
                }
                
                Button("Next"){
                           //self.scale = 0
                            
                            //self.positionX1 += 200
                            //self.positionX2 -= 200
                            self.animationAmount = 10000000
                            PlaygroundPage.current.setLiveView(FoldingSheetView())
                        }
                        .padding(20)
                        .background(Color.black)
                        .foregroundColor(.white)
                        .cornerRadius(20)
                        .clipShape( Rectangle())
                        .opacity(Double(opacityButton))
                        .position(x:200, y: 400 )
                        .animation(.linear(duration: 2).delay(9),
                                   value: opacityButton)
                       /* .overlay(
                            Circle()
                                .stroke(Color.red)
                                .scaleEffect(animationAmount)
                                .cornerRadius(20)
                                .opacity(Double(2 - animationAmount))
                                .position(x: CGFloat(positionX1), y: CGFloat(positionY1) )
                                .animation(Animation.easeInOut(duration:1)
                                            .repeatForever(autoreverses: false))
                        )*/
                        .onAppear{

                            self.animationAmount = 0.55
                            self.opacityButton = 1
                            
                        }
            
            
            }
            .frame(width: 400, height:560)
            .preferredColorScheme(.dark)
            .onAppear(){
                SoundManager.instance.playSound(sound: .sound1)
            }
            
        }
        
            
                       
            
}


    PlaygroundPage.current.setLiveView(IntroView())


struct FoldingSheetView: View {
    
    @State var rotation = 0.0
    @State var scalaXY = 1.0
    @State var positionY = 0
    @State var opacity_text1 = 0
    @State var opacity_text2 = 0
    @State var opacity_text3 = 0
    @State var opacity_text4 = 0
    @State var opacity_frame = 0
    @State var scalaXYC = 1.00
    @State var showMe = true
    @State var opacityButton = 0
    @State var animationAmount: CGFloat = 0.0
    
    var body: some View {
        
            ZStack {
                
                //"\nOne day the sheet was folded..."
                
                ZStack {
                    
                Image(uiImage: UIImage(named:"Frame 1.jpg")!)
                           .resizable()
                       .frame(width: 600, height: 835)
                       //.offset(x: 0, y: 48)
                       .scaleEffect(CGFloat(scalaXYC))
                       .animation(Animation.easeInOut(duration:9))
                       .onAppear(){
                           scalaXYC = 0.25

                       }
                    
                Text("\nOne day the sheet was folded...")
                    .font(.system(size: 17, weight: .light, design: .rounded))
                    .foregroundColor(.black)
                    .italic()
                    .opacity(Double(opacity_text1))
                    .animation(Animation.easeInOut(duration:3))
                    .onAppear() {
                        opacity_text1 += 1
                                    }
                }
                
                
                
            
                Image(uiImage: UIImage(named:"Frame 1.jpg")!)
                .resizable()
                .frame(width: 400, height: 560)
            // .offset(x: 0, y: 48)
            .opacity(Double(opacity_frame))
         //   .scaleEffect(CGFloat(scalaXYC))
            .animation(Animation.easeInOut(duration:3).delay(4))
            .onAppear(){
                 opacity_frame += 1
                
            }
                
                
                Image(uiImage: UIImage(named:"Frame 2.jpg")!)
                .resizable()
                .frame(width: 400, height: 560)
                .opacity(Double(opacity_frame))
                .animation(Animation.easeInOut(duration:3).delay(4.2))
                .onAppear(){
                     opacity_frame += 10
                    
                }
                
                
                
                Image(uiImage: UIImage(named:"Frame 3.jpg")!)
                .resizable()
                .frame(width: 400, height: 560)
                .opacity(Double(opacity_frame))
                .animation(Animation.easeInOut(duration:4).delay(4.4))
                .onAppear(){
                     opacity_frame += 10
                    
                }
                
                Image(uiImage: UIImage(named:"Frame 4.jpg")!)
                .resizable()
                .frame(width: 400, height: 560)
                .opacity(Double(opacity_frame))
                .animation(Animation.easeInOut(duration:3).delay(4.6))
                .onAppear(){
                     opacity_frame += 10
                    scalaXYC += 10
                }
                
                Image(uiImage: UIImage(named:"Frame 5.jpg")!)
                .resizable()
                .frame(width: 400, height: 560)
                .opacity(Double(opacity_frame))
                .animation(Animation.easeInOut(duration:3).delay(4.8))
                .onAppear(){
                     opacity_frame += 6
                    
                }
                
                Image(uiImage: UIImage(named:"Frame 6.jpg")!)
                .resizable()
                .frame(width: 400, height: 560)
                .opacity(Double(opacity_frame))
                .animation(Animation.easeInOut(duration:3).delay(5.0))
                .onAppear(){
                     opacity_frame += 6
                    
                }
                
                Image(uiImage: UIImage(named:"Frame 7.jpg")!)
                .resizable()
                .frame(width: 400, height: 560)
                .opacity(Double(opacity_frame))
                .animation(Animation.easeInOut(duration:3).delay(5.2))
                .onAppear(){
                     opacity_frame += 6
                }
                
                Image(uiImage: UIImage(named:"Frame 7.jpg")!)
                .resizable()
                .frame(width:400, height: 560)
                .opacity(Double(opacity_frame))
                .offset(y: CGFloat(positionY))
                .rotationEffect(.degrees(rotation))
                .scaleEffect(CGFloat(scalaXY))
                .animation(Animation.easeInOut(duration: 3).delay(5.4))
                .onAppear(){
                rotation += 90
                    scalaXY += 1.2
                opacity_frame += 6
                
                positionY = -95
                    
                }
                
                
                Button("Next"){
                           //self.scale = 0
                            
                            //self.positionX1 += 200
                            //self.positionX2 -= 200
                            self.animationAmount = 10000000
                            PlaygroundPage.current.setLiveView(SeparetedView())
                        }
                        .padding(15)
                        .background(Color.black)
                        .foregroundColor(.white)
                        .cornerRadius(15)
                        .clipShape( Rectangle())
                        .opacity(Double(opacityButton))
                        .position(x:300, y: 525 )
                        .animation(.linear(duration: 2).delay(8),
                                   value: opacityButton)
                       /* .overlay(
                            Circle()
                                .stroke(Color.red)
                                .scaleEffect(animationAmount)
                                .cornerRadius(20)
                                .opacity(Double(2 - animationAmount))
                                .position(x: CGFloat(positionX1), y: CGFloat(positionY1) )
                                .animation(Animation.easeInOut(duration:1)
                                            .repeatForever(autoreverses: false))
                        )*/
                        .onAppear{

                            self.animationAmount = 0.55
                            self.opacityButton = 1
                            
                        }
            
            }
            .frame(width: 400, height:560)
            .preferredColorScheme(.dark)

            
        }
            
                       
            
}




struct SeparetedView: View {
    
    @State var rotation = 0.0
    @State var scalaXY = 1.0
    @State var positionX = 0
    @State var positionX1 = 0
    @State var positionY = 0
    @State var positionY1 = 0
    @State var opacity_text1 = 0
    @State var opacity_text2 = 0
    @State var opacity_text3 = 0
    @State var opacity_text4 = 0
    @State var opacity_circle1 = 0
    @State var scalaXYC = 1
    @State var showMe = true
    @State var opacityButton = 0
    @State var animationAmount: CGFloat = 0.0
    
    var body: some View {
        
        
            ZStack {
                
            Image(uiImage: UIImage(named:"sheet.jpeg")!)
                    
            
            
    
                Image(uiImage: UIImage(named:"greendot1.png")!)
                    .resizable()
                .frame(width: 40, height: 40)
                
                .offset(x: CGFloat(positionX))
                .animation(Animation.easeInOut(duration:3).delay(1))
                .onAppear(){
                     opacity_circle1 += 4
                    positionX = 180
                    
                }
            
                Image(uiImage: UIImage(named:"yellowdot1.png")!)
                    .resizable()
                .frame(width: 40, height: 40)
                .offset(x: CGFloat(positionX1))
                .animation(Animation.easeInOut(duration:3).delay(1))
                .onAppear(){
                     opacity_circle1 += 1
                    positionX1 = -180
                    
                    
                    
                }
                
                Text("The sudden encounter frightens them\n and initially they can not communicate.")
                    .font(.system(size: 17, weight: .light, design: .rounded))
                        .foregroundColor(.black)
                        .italic()
                        .opacity(Double(opacity_text3))
                        .animation(Animation.easeInOut(duration:4).delay(2))
                        .onAppear() {
                            
                            opacity_text3 += 1
                        }
                Button("Next"){
                           //self.scale = 0
                            
                            //self.positionX1 += 200
                            //self.positionX2 -= 200
                            self.animationAmount = 10000000
                            PlaygroundPage.current.setLiveView(CherryView())
                        }
                        .padding(15)
                        .background(Color.black)
                        .foregroundColor(.white)
                        .cornerRadius(15)
                        .clipShape( Rectangle())
                        .opacity(Double(opacityButton))
                        .position(x:200, y: 400 )
                        .animation(.linear(duration: 2).delay(5),
                                   value: opacityButton)
                       /* .overlay(
                            Circle()
                                .stroke(Color.red)
                                .scaleEffect(animationAmount)
                                .cornerRadius(20)
                                .opacity(Double(2 - animationAmount))
                                .position(x: CGFloat(positionX1), y: CGFloat(positionY1) )
                                .animation(Animation.easeInOut(duration:1)
                                            .repeatForever(autoreverses: false))
                        )*/
                        .onAppear{

                            self.animationAmount = 0.55
                            self.opacityButton = 1
                            
                        }
               
                
              
            
            }
            .frame(width: 400, height:560)
            .preferredColorScheme(.dark)

            
        }
            
                       
            
}

struct CherryView: View {
    
    @State var rotation = 0.0
    @State var scalaXY = 1.0
    @State var positionX = 180
    @State var positionX1 = -180
    @State var positionY = 0
    @State var positionY1 = 0
    @State var opacity_text1 = 1
    @State var opacity_text2 = 0
    @State var opacity_text3 = 0
    @State var opacity_text4 = 0
    @State var opacity_circle1 = 0
    @State var opacity_circle2 = 0
    @State var scalaXYC = 1
    @State var showMe = true
    @State var position = false
    @State var opacityButton = 0
    @State var animationAmount: CGFloat = 0.0
    
    var body: some View {
        
        
            ZStack {
                
            Image(uiImage: UIImage(named:"sheet.jpeg")!)
                    
                
               
                Text("  After a while, they start to comunicate \n   blending and creating new shapes...")
                    .font(.system(size: 17, weight: .light, design: .rounded))
                    .foregroundColor(.black)
                    .italic()
                    .opacity(Double(opacity_text1))
                    .animation(Animation.easeInOut(duration:9))
                    .onAppear() {
                        opacity_text1 = 0
                                    }
                                
            
    
                Image(uiImage: UIImage(named:"greendot1.png")!)
                    .resizable()
                .frame(width: 40, height: 40)
                
                .offset(x: CGFloat(positionX))
                .animation(Animation.easeInOut(duration:3).delay(8))
                .onAppear(){
                     
                    positionX = -18
                    
                }
            
                Image(uiImage: UIImage(named:"yellowdot1.png")!)
                    .resizable()
                .frame(width: 40, height: 40)
                .offset(x: CGFloat(positionX1))
                .animation(Animation.easeInOut(duration:3).delay(8))
                .onAppear(){
                     
                    positionX1 = 18
                    
                    
                    
                }
                
                Image(uiImage: UIImage(named:"cherry0.png")!)
                    .resizable()
                .frame(width: 110, height: 150)
                .offset(x: -2, y:-10)
                .opacity(Double(opacity_circle2))
                .animation(Animation.easeInOut(duration:0.5).delay(12))
                .onAppear(){
                     opacity_circle2 = 1
                }
               
                Image(uiImage: UIImage(named:"cherry.png")!)
                    .resizable()
                .frame(width: 110, height: 150)
                .opacity(Double(opacity_circle2))
                .offset(x: -2, y:-10)
                .animation(Animation.easeInOut(duration:0.5).delay(14))
                .onAppear(){
                     opacity_circle2 += 1
                }
                
                Button("Next"){
                           //self.scale = 0
                            
                            //self.positionX1 += 200
                            //self.positionX2 -= 200
                            self.animationAmount = 10000000
                            PlaygroundPage.current.setLiveView(SnowmanView())
                        }
                        .padding(15)
                        .background(Color.black)
                        .foregroundColor(.white)
                        .cornerRadius(15)
                        .clipShape( Rectangle())
                        .opacity(Double(opacityButton))
                        .position(x:200, y: 400 )
                        .animation(.linear(duration: 2).delay(15),
                                   value: opacityButton)
                       /* .overlay(
                            Circle()
                                .stroke(Color.red)
                                .scaleEffect(animationAmount)
                                .cornerRadius(20)
                                .opacity(Double(2 - animationAmount))
                                .position(x: CGFloat(positionX1), y: CGFloat(positionY1) )
                                .animation(Animation.easeInOut(duration:1)
                                            .repeatForever(autoreverses: false))
                        )*/
                        .onAppear{

                            self.animationAmount = 0.55
                            self.opacityButton = 1
                            
                        }
        
                
            
            }
            .frame(width: 400, height:560)
            .preferredColorScheme(.dark)

            
        }
            
                       
            
}


struct SnowmanView: View {
    
    @State var rotation = 0.0
    @State var scalaXY = 1.0
    @State var positionX = -18
    @State var positionX1 = 18
    @State var positionY = 0
    @State var positionY1 = 0
    @State var opacity_text1 = 1
    @State var opacity_text2 = 0
    @State var opacity_text3 = 0
    @State var opacity_text4 = 0
    @State var opacity_circle1 = 0
    @State var opacity_circle2 = 0
    @State var scalaXYC = 1
    @State var showMe = true
    @State var opacityButton = 0
    @State var animationAmount: CGFloat = 0.0
    
    var body: some View {
        
        
            ZStack {
                Image(uiImage: UIImage(named:"sheet.jpeg")!)
                    
               
                
                Image(uiImage: UIImage(named:"greendot1.png")!)
                    .resizable()
                .frame(width: 40, height: 40)
                
                .offset(x: CGFloat(positionX), y: CGFloat(positionY))
                .animation(Animation.easeInOut(duration:3).delay(4))
                .onAppear(){
                    positionX = -6
                    positionY = -14
                    
                }
            
                Image(uiImage: UIImage(named:"yellowdot1.png")!)
                    .resizable()
                .frame(width: 40, height: 40)
                .offset(x: CGFloat(positionX1), y: CGFloat(positionY1))
                .animation(Animation.easeInOut(duration:3).delay(4))
                .onAppear(){
                    positionX1 = -6
                    positionY1 = 20
                    
                    
                    
                }
                
                Image(uiImage: UIImage(named:"cherry0.png")!)
                    .resizable()
                .frame(width: 110, height: 150)
                .opacity(Double(opacity_text1))
                .offset(x: -2, y:-10)
                .animation(Animation.easeInOut(duration:1).delay(3))
                .onAppear(){
                     opacity_text1 = 0
                }
               
                    
                    Image(uiImage: UIImage(named:"cherry.png")!)
                        .resizable()
                    .frame(width: 110, height: 150)
                    .opacity(Double(opacity_text1))
                    .offset(x: -2, y:-10)
                    .animation(Animation.easeInOut(duration:3))
                    .onAppear(){
                         opacity_text1 = 0
                    }
                
                
                
                
                Image(uiImage: UIImage(named:"snowman0.png")!)
                    .resizable()
                .frame(width: 150, height: 190)
                .offset(x: -10, y:-2)
                .opacity(Double(opacity_circle2))
                .animation(Animation.easeInOut(duration:0.5).delay(8))
                .onAppear(){
                     opacity_circle2 = 1
                }
               
                Image(uiImage: UIImage(named:"snowman.png")!)
                    .resizable()
                .frame(width: 150, height: 190)
                .opacity(Double(opacity_circle2))
                .offset(x: -10, y:-2)
                .animation(Animation.easeInOut(duration:0.5).delay(10))
                .onAppear(){
                     opacity_circle2 += 1
                }
                
                Button("Next"){
                           //self.scale = 0
                            
                            //self.positionX1 += 200
                            //self.positionX2 -= 200
                            self.animationAmount = 10000000
                            PlaygroundPage.current.setLiveView(IcecreamView())
                        }
                        .padding(15)
                        .background(Color.black)
                        .foregroundColor(.white)
                        .cornerRadius(15)
                        .clipShape( Rectangle())
                        .opacity(Double(opacityButton))
                        .position(x:200, y: 400 )
                        .animation(.linear(duration: 2).delay(11),
                                   value: opacityButton)
                       /* .overlay(
                            Circle()
                                .stroke(Color.red)
                                .scaleEffect(animationAmount)
                                .cornerRadius(20)
                                .opacity(Double(2 - animationAmount))
                                .position(x: CGFloat(positionX1), y: CGFloat(positionY1) )
                                .animation(Animation.easeInOut(duration:1)
                                            .repeatForever(autoreverses: false))
                        )*/
                        .onAppear{

                            self.animationAmount = 0.55
                            self.opacityButton = 1
                            
                        }
                
                
            
            }
            .frame(width: 400, height:560)
            .preferredColorScheme(.dark)

            
        }
            
                       
            
}


struct IcecreamView: View {
    
    @State var rotation = 0.0
    @State var scalaXY = 1.0
    @State var positionX = -6
    @State var positionX1 = -6
    @State var positionY = -14
    @State var positionY1 = 20
    @State var opacity_text1 = 1
    @State var opacity_text2 = 0
    @State var opacity_text3 = 0
    @State var opacity_text4 = 0
    @State var opacity_circle1 = 0
    @State var opacity_circle2 = 0
    @State var scalaXYC = 1
    @State var showMe = true
    @State var opacityButton = 0
    @State var animationAmount: CGFloat = 0.0
    
    var body: some View {
        
        
            ZStack {
                Image(uiImage: UIImage(named:"sheet.jpeg")!)
                   
                
                Image(uiImage: UIImage(named:"greendot1.png")!)
                    .resizable()
                .frame(width: 40, height: 40)
                
                .offset(x: CGFloat(positionX), y: CGFloat(positionY))
                .animation(Animation.easeInOut(duration:3).delay(4))
                .onAppear(){
                    positionX = 18
                    positionY = 0
                    
                }
            
                Image(uiImage: UIImage(named:"yellowdot1.png")!)
                    .resizable()
                .frame(width: 40, height: 40)
                .offset(x: CGFloat(positionX1), y: CGFloat(positionY1))
                .animation(Animation.easeInOut(duration:3).delay(4))
                .onAppear(){
                    positionX1 = -18
                    positionY1 = 0
                    
                    
                    
                }
                
                Image(uiImage: UIImage(named:"snowman0.png")!)
                    .resizable()
                .frame(width: 150, height: 190)
                .opacity(Double(opacity_text1))
                .offset(x: -10, y:-2)
                .animation(Animation.easeInOut(duration:1).delay(3))
                .onAppear(){
                     opacity_text1 = 0
                }
               
                    
                    Image(uiImage: UIImage(named:"snowman.png")!)
                        .resizable()
                    .frame(width: 150, height: 190)
                    .opacity(Double(opacity_text1))
                    .offset(x: -10, y:-2)
                    .animation(Animation.easeInOut(duration:3))
                    .onAppear(){
                         opacity_text1 = 0
                    }
                
                
                
                
                Image(uiImage: UIImage(named:"icecream0.png")!)
                    .resizable()
                .frame(width: 155, height: 205)
                .offset(x: 1, y:14)
                .opacity(Double(opacity_circle2))
                .animation(Animation.easeInOut(duration:0.5).delay(8))
                .onAppear(){
                     opacity_circle2 = 1
                }
               
                Image(uiImage: UIImage(named:"icecream.png")!)
                    .resizable()
                .frame(width: 155, height: 205)
                .opacity(Double(opacity_circle2))
                .offset(x: 1, y:14)
                .animation(Animation.easeInOut(duration:0.5).delay(10))
                .onAppear(){
                     opacity_circle2 += 1
                }
                
                Button("Next"){
                           //self.scale = 0
                            
                            //self.positionX1 += 200
                            //self.positionX2 -= 200
                            self.animationAmount = 10000000
                            PlaygroundPage.current.setLiveView(JustBeforeOpeningView())
                        }
                        .padding(15)
                        .background(Color.black)
                        .foregroundColor(.white)
                        .cornerRadius(15)
                        .clipShape( Rectangle())
                        .opacity(Double(opacityButton))
                        .position(x:200, y: 400 )
                        .animation(.linear(duration: 2).delay(11),
                                   value: opacityButton)
                       /* .overlay(
                            Circle()
                                .stroke(Color.red)
                                .scaleEffect(animationAmount)
                                .cornerRadius(20)
                                .opacity(Double(2 - animationAmount))
                                .position(x: CGFloat(positionX1), y: CGFloat(positionY1) )
                                .animation(Animation.easeInOut(duration:1)
                                            .repeatForever(autoreverses: false))
                        )*/
                        .onAppear{

                            self.animationAmount = 0.55
                            self.opacityButton = 1
                            
                        }
        
                    
                
        
                
            
            
            
            }
            .frame(width: 400, height:560)
            .preferredColorScheme(.dark)

            
        }
            
                       
            
}

struct JustBeforeOpeningView: View {
    
    @State var rotation = 0.0
    @State var scalaXY = 1.0
    @State var positionX = 18
    @State var positionX1 = -18
    @State var positionY = 0
    @State var positionY1 = 0
    @State var opacity_text1 = 1
    @State var opacity_text2 = 0
    @State var opacity_text3 = 0
    @State var opacity_text4 = 0
    @State var opacity_circle1 = 0
    @State var opacity_circle2 = 0
    @State var scalaXYC = 1
    @State var showMe = true
    @State var opacityButton = 0
    @State var animationAmount: CGFloat = 0.0
    
    var body: some View {
        
        
            ZStack {
                Image(uiImage: UIImage(named:"sheet.jpeg")!)
                    
               
                
                Image(uiImage: UIImage(named:"greendot1.png")!)
                    .resizable()
                .frame(width: 40, height: 40)
                
                .offset(x: CGFloat(positionX), y: CGFloat(positionY))
                .animation(Animation.easeInOut(duration:7).delay(4))
                .onAppear(){
                    positionX = -120
                    positionY = -20
                    
                }
            
                Image(uiImage: UIImage(named:"yellowdot1.png")!)
                    .resizable()
                .frame(width: 40, height: 40)
                .offset(x: CGFloat(positionX1), y: CGFloat(positionY1))
                .animation(Animation.easeInOut(duration:7).delay(4))
                .onAppear(){
                    positionX1 = 120
                    positionY1 = 20
                    
                    
                    
                }
                
                Image(uiImage: UIImage(named:"icecream0.png")!)
                    .resizable()
                .frame(width: 155, height: 205)
                .opacity(Double(opacity_text1))
                .offset(x: 1, y:14)
                .animation(Animation.easeInOut(duration:1).delay(3))
                .onAppear(){
                     opacity_text1 = 0
                }
               
                    
                    Image(uiImage: UIImage(named:"icecream.png")!)
                        .resizable()
                    .frame(width: 155, height: 205)
                    .opacity(Double(opacity_text1))
                    .offset(x: 1, y:14)
                    .animation(Animation.easeInOut(duration:3))
                    .onAppear(){
                         opacity_text1 = 0
                    }
                
                
                
                
                
                
                Text("But suddenly...")
                    .font(.system(size: 17, weight: .light, design: .rounded))
                        .foregroundColor(.black)
                        .italic()
                        .opacity(Double(opacity_text3))
                        .animation(Animation.easeInOut(duration:7).delay(6))
                        .onAppear() {
                            
                            opacity_text3 += 1
                        }
        
                Button("Next"){
                           
                            self.animationAmount = 10000000
                            PlaygroundPage.current.setLiveView(OpeningSheetView())
                        }
                        .padding(15)
                        .background(Color.black)
                        .foregroundColor(.white)
                        .cornerRadius(15)
                        .clipShape( Rectangle())
                        .opacity(Double(opacityButton))
                        .position(x:200, y: 400 )
                        .animation(.linear(duration: 2).delay(8),
                                   value: opacityButton)
                    
                        .onAppear{

                            self.animationAmount = 0.55
                            self.opacityButton = 1
                            
                        }
                
        
                
            
            
            
            }
            .frame(width: 400, height:560)
            .preferredColorScheme(.dark)

            
        }
            
                       
            
}


struct OpeningSheetView: View {
    
    @State var rotation = 0.0
    @State var scalaXY = 1.0
    @State var positionY = 0
    @State var positionX = 200
    @State var opacity_text1 = 0
    @State var opacity_text2 = 0
    @State var opacity_text3 = 0
    @State var opacity_text4 = 0
    @State var opacity_frame = 0
    @State var opacity_frameA = 1
    @State var scalaXYC = 1.0
    @State var showMe = true
    @State var opacityButton = 0
    @State var animationAmount: CGFloat = 0.0
    
    var body: some View {
        
            ZStack {
               
                Image(uiImage: UIImage(named:"Frame 8.jpg")!)
                .resizable()
                .frame(width:1200, height: 900)
                .opacity(Double(opacity_frameA))
                .offset(x: CGFloat(positionX), y: CGFloat(positionY))
                .rotationEffect(.degrees(rotation))
                .scaleEffect(CGFloat(scalaXY))
                .animation(Animation.easeInOut(duration: 5))
                .onAppear(){
                
                   
                    rotation = -95
                    scalaXY = 0.4
                    opacity_frameA = 1
                    positionY = -10
                    positionX = -50
                    
                }
                    
                Image(uiImage: UIImage(named:"Frame 6.jpg")!)
                .resizable()
                .frame(width: 400, height: 560)
            //  .offset(x: 0, y: 48)
                .opacity(Double(opacity_frame))
         //     .scaleEffect(CGFloat(scalaXYC))
                .animation(Animation.easeInOut(duration:3).delay(4))
                .onAppear(){
                 opacity_frame += 1
                }
                
                
                Image(uiImage: UIImage(named:"Frame 16.jpg")!)
                .resizable()
                .frame(width: 400, height: 560)
                .opacity(Double(opacity_frame))
                .animation(Animation.easeInOut(duration:3).delay(4.2))
                .onAppear(){
                     opacity_frame += 10
                    
                }
                
                
                
                Image(uiImage: UIImage(named:"Frame 17.jpg")!)
                .resizable()
                .frame(width: 400, height: 560)
                .opacity(Double(opacity_frame))
                .animation(Animation.easeInOut(duration:4).delay(4.4))
                .onAppear(){
                     opacity_frame += 10
                    
                }
                
                Image(uiImage: UIImage(named:"Frame 18.jpg")!)
                .resizable()
                .frame(width: 400, height: 560)
                .opacity(Double(opacity_frame))
                .animation(Animation.easeInOut(duration:3).delay(4.6))
                .onAppear(){
                     opacity_frame += 10
                    scalaXYC += 10
                }
                
                Image(uiImage: UIImage(named:"Frame 19.jpg")!)
                .resizable()
                .frame(width: 400, height: 560)
                .opacity(Double(opacity_frame))
                .animation(Animation.easeInOut(duration:3).delay(4.8))
                .onAppear(){
                     opacity_frame += 6
                    
                }
                
                Image(uiImage: UIImage(named:"Frame 20.jpg")!)
                .resizable()
                .frame(width: 400, height: 560)
                .opacity(Double(opacity_frame))
                .animation(Animation.easeInOut(duration:3).delay(5.0))
                .onAppear(){
                     opacity_frame += 6
                    
                }
                
           
                Image(uiImage: UIImage(named:"Frame 20.jpg")!)
                           .resizable()
                           .frame(width: 400, height: 560)
                           .opacity(Double(opacity_frame))
                           .scaleEffect(1.5)
                           .animation(Animation.easeInOut(duration: 5).delay(5.2))
                       .onAppear(){
                           opacity_frame += 6
                           scalaXYC  += 1.5
                       }
                    
                Text("              The points are separated again, \n  but thanks to their meet something is changed...")
                        .font(.system(size: 17, weight: .light, design: .rounded))
                        .foregroundColor(.black)
                        .italic()
                        .opacity(Double(opacity_text1))
                        .animation(Animation.easeInOut(duration:3).delay(5.3))
                        .onAppear() {
                            opacity_text1 += 1
                                        }
                ZStack {
                Image(uiImage: UIImage(named:"sheet.jpeg")!)
                           .resizable()
                           .frame(width: 400, height: 560)
                           .opacity(Double(opacity_frame))
                           .scaleEffect(1.5)
                           .animation(Animation.easeInOut(duration: 5).delay(12))
                       .onAppear(){
                           opacity_frame += 6
                           scalaXYC  += 1.5
                           
                       }
                    Text("The end")
                            .font(.system(size: 80, weight: .light, design: .rounded))
                            .foregroundColor(.black)
                            .italic()
                            .opacity(Double(opacity_text1))
                            .animation(Animation.easeInOut(duration:3).delay(13))
                            .onAppear() {
                                opacity_text1 += 1
                                            }
                    Image(uiImage: UIImage(named:"Mixed1.png")!)
                        .resizable()
                    .frame(width: 100, height: 100)
                    .opacity(Double(opacity_frame))
                    .offset(x: -90, y: -180)
                    .animation(Animation.easeInOut(duration:7).delay(14))
                    .onAppear(){
                        opacity_frame += 1

                    }
                
                    Image(uiImage: UIImage(named:"Mixed2.png")!)
                        .resizable()
                    .opacity(Double(opacity_frame))
                    .frame(width: 100, height: 100)
                    .offset(x: 90, y: 180)
                    .animation(Animation.easeInOut(duration:7).delay(14))
                    .onAppear(){
                        
                        opacity_frame += 1
                    }
                    
                    
                    
                }
                   
                
              
                
                
            
            }
            .frame(width: 400, height:560)
            .preferredColorScheme(.dark)

            
        }
            
                       
            
}


//: [FoldingSheet](@next)
